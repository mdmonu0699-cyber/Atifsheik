package com.example.makkahliveclock

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = android.view.Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "Makkah Live Clock\n\nOriginal tower photo with real-time moving clock hands."
            textSize = 20f
            gravity = android.view.Gravity.CENTER
        }
        val button = Button(this).apply {
            text = "Set Live Wallpaper"
            setOnClickListener {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, MakkahWallpaperService::class.java))
                }
                startActivity(intent)
            }
        }
        layout.addView(title)
        layout.addView(button)
        setContentView(layout)
    }
}
