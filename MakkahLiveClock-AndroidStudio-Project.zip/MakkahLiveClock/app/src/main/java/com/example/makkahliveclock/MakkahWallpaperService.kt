package com.example.makkahliveclock

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.max

class MakkahWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val bitmap by lazy {
            BitmapFactory.decodeResource(resources, R.drawable.tower)
        }
        private var visible = false
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(198, 160, 86)
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x668F6B2F
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
        private val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(221, 190, 119)
            style = Paint.Style.FILL
        }
        private val tick = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000L)
            }
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            handler.removeCallbacks(tick)
            if (visible) handler.post(tick)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val w = canvas.width.toFloat()
                    val h = canvas.height.toFloat()
                    val s = max(w / bitmap.width, h / bitmap.height)
                    val bw = bitmap.width * s
                    val bh = bitmap.height * s
                    val left = (w - bw) / 2f
                    val top = (h - bh) / 2f
                    canvas.drawBitmap(bitmap, null, RectF(left, top, left + bw, top + bh), bgPaint)

                    // Center of the main front clock dial in the supplied source photograph.
                    val cx = left + 440f * s
                    val cy = top + 940f * s
                    val r = 64f * s
                    val now = Calendar.getInstance()
                    val millis = now.get(Calendar.MILLISECOND)
                    val seconds = now.get(Calendar.SECOND) + millis / 1000f
                    val minutes = now.get(Calendar.MINUTE) + seconds / 60f
                    val hours = (now.get(Calendar.HOUR) % 12) + minutes / 60f
                    val secondAngle = seconds * 6f
                    val minuteAngle = minutes * 6f
                    val hourAngle = hours * 30f

                    canvas.save()
                    canvas.translate(cx, cy)
                    drawHand(canvas, hourAngle, r * 0.48f, 5.2f * s, goldPaint, glowPaint)
                    drawHand(canvas, minuteAngle, r * 0.73f, 3.6f * s, goldPaint, glowPaint)
                    drawHand(canvas, secondAngle, r * 0.83f, 1.5f * s, goldPaint, glowPaint)
                    canvas.drawCircle(0f, 0f, 4.2f * s, hubPaint)
                    canvas.restore()
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun drawHand(c: Canvas, degrees: Float, length: Float, width: Float, main: Paint, glow: Paint) {
            val rad = Math.toRadians((degrees - 90f).toDouble())
            val x = kotlin.math.cos(rad).toFloat() * length
            val y = kotlin.math.sin(rad).toFloat() * length
            glow.strokeWidth = width * 3.2f
            c.drawLine(0f, 0f, x, y, glow)
            main.strokeWidth = width
            c.drawLine(0f, 0f, x, y, main)
        }
    }
}
