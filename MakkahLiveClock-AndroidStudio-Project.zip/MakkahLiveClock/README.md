# Makkah Live Clock (Android Studio project)

This project creates an Android live wallpaper using the supplied Makkah tower photograph. The front clock face gets moving hour, minute and second hands based on the phone's local time.

## Build and install
1. Install Android Studio on a computer and open this `MakkahLiveClock` folder.
2. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on the Motorola G96.
5. Open **Makkah Live Clock** and tap **Set Live Wallpaper**.

The wallpaper draws at one update per second while visible. The static hands in the original dial are lightly inpainted in the included image so the live hands can replace them. Clock alignment may need a small adjustment on devices with unusual wallpaper cropping; the dial center is set to source-image coordinate (440, 940).
